# Flux & Variance Commentary — November 2026
**Entity:** LuminaUS (Consolidated)  
**Period:** Nov-26 (2026-11)  
**Preparer:** Flux & Variance Agent v0.1.0  
**Reviewer:** FP&A Manager  
**Status:** ✅ Commentary approved — BD4 14:30 PT

---

## 1. Period overview

November 2026 revenue of **$152.4M** came in **$1.4M unfavorable to budget** (-0.9%), driven primarily by an advertising shortfall in APAC. Gross margin was **54.8%**, approximately 120bps below budget, reflecting the CDN cost overrun. Operating income of **$18.2M** was **$2.4M unfavorable to budget** (-11.7%), with the Marketing Performance overage as the largest driver. All three variances are explained and have clear business context. No unexplained anomaly flags.

---

## 2. Revenue

### Subscription Revenue — 400100
- **Actual:** $128,600,000
- **Budget:** $128,000,000
- **Variance:** +$600,000 favorable (+0.5%)
- **MoM:** +$1,200,000 vs. October (+0.9%)

Subscription revenue was $0.6M favorable to budget, reflecting stronger-than-forecast net subscriber additions in the US and EMEA markets. APAC subs were slightly below forecast but offset by higher ARPU in the US tier mix. Consistent with Q4 trend.

### Advertising Revenue — 400200
- **Actual:** $18,100,000
- **Budget:** $18,800,000
- **Variance:** ($700,000) unfavorable (-3.8%) ⚠️ BvA flag
- **MoM:** ($420,000) vs. October (-2.3%) ⚠️ MoM flag

**Advertising Revenue** was $0.7M unfavorable to November budget (-3.8%). The shortfall is concentrated in APAC, where inventory sell-through was 74% vs. an 85% budget assumption. The APAC programmatic ad platform migration was delayed, reducing automated fill rates for most of November. The migration completed November 28, and December rates are expected to normalize to ~82%. The US and EMEA ad markets performed at or above budget.

### Other Revenue — 400300
- **Actual:** $5,700,000
- **Budget:** $5,600,000
- **Variance:** +$100,000 favorable (+1.8%)

Immaterial. No commentary required.

---

## 3. Cost of goods sold

### Content Amortization — 500100
- **Actual:** $4,200,000
- **Budget:** $4,200,000
- **Variance:** $0 (flat to budget)

Straight-line amortization per schedule. No variance.

### Streaming Delivery (CDN) — 500200
- **Actual:** $8,850,000
- **Budget:** $8,050,000
- **Variance:** ($800,000) unfavorable (-9.9%) ⚠️ BvA flag
- **MoM:** ($650,000) vs. October (-7.9%) ⚠️ MoM flag

**Streaming Delivery (CDN)** was $0.8M unfavorable to budget (-9.9%). Volume-driven: November streaming hours were 12% above forecast, attributable to new original content releases on November 7 and November 21 that drove sustained viewing spikes. CDN unit rates were flat to contract. Engineering has been asked to model Q1 CDN contract renegotiation options given sustained volume growth. No accounting action required; variance is fully volume-attributed.

### Royalties — 500300
- **Actual:** $10,800,000
- **Budget:** $10,900,000
- **Variance:** +$100,000 favorable (+0.9%)

Immaterial. No commentary required.

---

## 4. Operating expenses

### Marketing - Performance — 600100
- **Actual:** $17,340,000 (post JE-PROP-004 reversal)
- **Budget:** $15,000,000 (gross before reversal: $17,680,000; budget: $15,000,000)
- **Variance:** ($2,660,000) unfavorable (-17.7%) ⚠️ BvA flag (note: gross variance pre-reversal was $3.0M unfavorable)
- **MoM:** ($2,150,000) vs. October (-14.2%) ⚠️ MoM flag

**Marketing - Performance** was $2.66M unfavorable to budget (-17.7%) after reflecting the $340K stale accrual reversal approved in the accrual review. The remaining overage reflects accelerated Q4 subscriber acquisition spend on Meta, Google, and connected TV platforms. The Q4 campaign was launched approximately two weeks ahead of the original plan based on a competitor campaign event, pulling forward spend that was originally budgeted for December. FP&A Manager has confirmed via campaign brief MKT-2026-11-042 that December Performance Marketing budget will be reduced by a corresponding $2.66M. Full-year spend remains on track. No additional accounting action required.

### Marketing - Brand — 600200
- **Actual:** $4,200,000
- **Budget:** $4,300,000
- **Variance:** +$100,000 favorable (+2.3%)

Note: $1.5M was reclassified from Performance to Brand via JE-2026-11-0042 (reviewed and supported by Controller on BD3). On a combined Marketing basis, total spend was $21.54M vs. $19.3M budget (-$2.24M, -11.6%).

### Salaries - Engineering — 600400
- **Actual:** $12,400,000
- **Budget:** $12,600,000
- **Variance:** +$200,000 favorable (+1.6%)

Two open headcount positions; favorable timing.

### Salaries - G&A — 600500
- **Actual:** $8,100,000
- **Budget:** $8,000,000
- **Variance:** ($100,000) unfavorable (-1.3%)

Immaterial. No commentary required.

### Tech Infrastructure — 600600
- **Actual:** $5,580,000 (includes $380K software amortization JE-PROP-006)
- **Budget:** $5,600,000
- **Variance:** +$20,000 favorable

Immaterial.

### All other OpEx
No material variances. All accounts within threshold.

---

## 5. Non-operating items

### Interest Income — 700100
- **Actual:** $208,200 (includes $8,200 MM interest — JE-PROP-002)
- **Budget:** $190,000
- **Variance:** +$18,200 favorable

Money market yield slightly above budget assumption. Immaterial.

### FX Gain/Loss — 700300
- **Actual:** ($127,200) loss
- **Budget:** $0
- **Variance:** ($127,200) unfavorable

FX translation adjustment on IC EMEA receivable (EUR/USD rate movement November 28 to 30). Documented in IC rec. Immaterial to consolidated results.

---

## 6. Anomaly flags

None. All material variances have confirmed drivers. No accounts were flagged as unexplained.

---

## 7. FP&A Manager sign-off

**FP&A Manager — approved 2026-12-04T14:30:00Z**  
Commentary reviewed and approved. Marketing pull-forward confirmed per campaign brief. CDN volume driver confirmed per engineering. APAC ad shortfall documented. All three BvA variances are explained. No further action required before TB lock.

---

*Flux & Variance Agent v0.1.0 · Sources: TrialBalance (lumina_close_dataset.xlsx) · AccrualRec envelope · Run: 2026-12-04T10:45:00Z*
