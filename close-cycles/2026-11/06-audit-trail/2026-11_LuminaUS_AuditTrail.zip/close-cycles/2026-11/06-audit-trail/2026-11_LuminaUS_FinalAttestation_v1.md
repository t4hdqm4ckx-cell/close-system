# Final Close Attestation — November 2026
**Entity:** Lumina Streaming USA, Inc. (LuminaUS) — Consolidated  
**Period:** Nov-26 (2026-11)  
**Document type:** Final attestation  
**Issued by:** Close Orchestrator v0.1.0  
**Issued at:** 2026-12-05T17:00:00Z  
**Archive path:** `/close-cycles/2026-11/06-audit-trail/2026-11_LuminaUS_FinalAttestation_v1.md`

---

## Attestation

The Lumina Streaming USA, Inc. November 2026 month-end close is hereby declared **complete and clean** as of December 5, 2026 (BD5).

The following conditions have been satisfied:

- [x] Accounting period closed in the GL — November 30, 2026, 23:59:59 PT
- [x] All sub-ledger feeds loaded and treated as read-only
- [x] All balance sheet accounts reconciled (bank, intercompany, accruals, AR/AP, prepaid)
- [x] All reconciliation exceptions resolved within the close calendar
- [x] JE review complete — all 47 entries reviewed; one high-severity exception identified and resolved
- [x] All 7 proposed adjusting JEs reviewed, approved, and posted
- [x] Flux and variance analysis complete — all 3 material BvA variances explained and approved by FP&A Manager
- [x] TB reviewed and directional checks passed — Controller attestation
- [x] Final trial balance locked — December 5, 2026, 08:55 PT
- [x] Close package assembled and delivered (executive memo, KPI dashboard, board snippets)
- [x] CFO sign-off received — December 5, 2026, 15:00 PT
- [x] Reporting submission complete — December 5, 2026, 16:45 PT

**No open items. No unresolved exceptions. The close is clean.**

---

## Close timeline summary

| Business day | Date | Gate | Passed |
|---|---|---|---|
| BD1 | December 1, 2026 | Controller: period closed, feeds loaded, bank statements received | ✅ 17:45 PT |
| BD2 | December 2, 2026 | Controller: all four recs reviewed, no unresolved high-severity exceptions | ✅ 16:45 PT |
| BD3 | December 3, 2026 | Controller: amortization ties to GL, no close-blocking JE exceptions | ✅ 16:00 PT |
| BD4 | December 4, 2026 | CFO: material variances explained, all JEs approved, TB review complete | ✅ 17:20 PT |
| BD5 | December 5, 2026 | TB locked, close package approved, attestation issued | ✅ 17:00 PT |

Close completed within the 5-business-day target.

---

## Exception register — final status

| Exception | Source | Severity | Resolution | Closed |
|---|---|---|---|---|
| Outstanding check #14872 ($18,400, 47 days) | Bank rec | Low | Monitor; void at 60 days if not cleared | Noted — carry to Dec |
| IC US/EMEA FX translation diff ($127,200) | IC rec | Medium | LuminaEMEA FX adj JE posted BD2 | ✅ BD2 |
| Stale accrual 210400 ($340,000, 91 days) | Accrual rec | Medium | Reversal JE-PROP-004 posted BD4 | ✅ BD4 |
| AR 90+ day bucket at 3.8% | AR/AP tie-out | Low | Below 5% threshold; monitor Dec | Noted — carry to Dec |
| JE-2026-11-0042 ($1.5M, Saturday, missing support) | JE review | High | Support MKT-2026-11-042 obtained; Controller accepted BD3 | ✅ BD3 |
| Marketing - Performance BvA ($2.66M, -17.7%) | Flux analysis | Medium | Q4 pull-forward; Dec budget reduced; FP&A approved | ✅ BD4 |
| CDN BvA ($0.80M, -9.9%) | Flux analysis | Medium | Volume-driven; FP&A approved | ✅ BD4 |
| Advertising Revenue APAC BvA ($0.70M, -3.8%) | Flux analysis | Medium | Platform migration; FP&A approved | ✅ BD4 |

**Open carry-forwards to December cycle:** 2 (both low severity — outstanding check monitoring, AR aging monitoring)

---

## Adjusting entries posted — final register

| JE ref | Description | Debit acct | Credit acct | Amount | Posted |
|---|---|---|---|---|---|
| JE-PROP-001 | Bank service charge | 600700 | 100100 | $1,800 | BD4 |
| JE-PROP-002 | MM interest income | 100200 | 700100 | $8,200 | BD4 |
| JE-PROP-003 | IC FX adj (LuminaEMEA) | 700300 | 230100 | $127,200 | BD4 |
| JE-PROP-004 | Reverse stale accrual | 210400 | 600100 | $340,000 | BD4 |
| JE-PROP-005 | Content amortization | 500100 | 120100 | $4,200,000 | BD4 |
| JE-PROP-006 | Software amortization | 600600 | 120200 | $380,000 | BD4 |
| JE-PROP-007 | Insurance amortization | 600700 | 120300 | $95,000 | BD4 |
| **Total** | | | | **$5,152,200** | |

---

## Specialist agent performance

| Agent | Invoked | Output | Exceptions found | Exceptions resolved | Status |
|---|---|---|---|---|---|
| Reconciliation (BD2) | 2026-12-02T08:00Z | 4 rec workpapers + memos | 4 (0 high, 2 medium, 2 low) | 2 medium resolved; 2 low noted | ✅ Complete |
| Reconciliation (BD3 amortization) | 2026-12-03T08:00Z | 1 rec workpaper + memo | 0 | n/a | ✅ Complete |
| JE Reviewer | 2026-12-03T08:00Z | Review memo | 1 (high) | 1 resolved | ✅ Complete |
| Flux & Variance | 2026-12-04T08:00Z | Flux file + commentary | 3 (medium) | 3 resolved | ✅ Complete |
| Close Reporting | 2026-12-05T08:00Z | Executive memo + KPI dashboard + board snippets | 0 | n/a | ✅ Complete |

---

## Carry-forwards for December cycle

| Item | Type | Owner | Action |
|---|---|---|---|
| Outstanding check #14872 ($18,400) | Monitoring | AP Manager | Void and re-issue if not cleared by December 17, 2026 |
| AR 90+ day bucket (3.8% of AR) | Monitoring | Assistant Controller | Flag if ≥5% at December 31 close |
| CDN contract renegotiation | Advisory | Engineering / FP&A | Model Q1 renegotiation options; brief to Controller by December 15 |

---

## Human sign-off record

| Role | Action | Timestamp |
|---|---|---|
| Controller | Period cutoff confirmed | 2026-12-01T22:32:00Z |
| Assistant Controller | Sub-ledger feeds confirmed loaded | 2026-12-01T23:47:00Z |
| AP Manager / Treasury | Bank statements confirmed loaded | 2026-12-02T00:58:00Z |
| AP Manager | Bank rec approved | 2026-12-02T19:30:00Z |
| Consolidations Lead | IC rec approved (post FX adj) | 2026-12-02T22:05:00Z |
| Accruals Team | Accrual rec approved | 2026-12-02T23:40:00Z |
| Assistant Controller | AR/AP tie-out approved | 2026-12-03T00:15:00Z |
| Controller | BD2 gate confirmed | 2026-12-03T00:45:00Z |
| Assistant Controller | Prepaid amortization approved | 2026-12-03T19:20:00Z |
| Assistant Controller | JE documentation obtained | 2026-12-03T22:22:00Z |
| Controller | JE exception accepted; BD3 gate confirmed | 2026-12-03T23:10:00Z |
| FP&A Manager | Flux commentary approved | 2026-12-04T22:30:00Z |
| Controller | TB review complete; all JEs posted | 2026-12-05T00:50:00Z |
| CFO | BD4 gate confirmed | 2026-12-05T01:20:00Z |
| Controller | Final TB locked | 2026-12-05T16:55:00Z |
| CFO | Close package approved | 2026-12-05T23:00:00Z |

---

## Audit trail — source files reviewed

| File | Contents | SHA-256 (synthetic) |
|---|---|---|
| lumina_close_dataset.xlsx | TrialBalance, JE_Log | c5f0e43f16g9d287h5c3f41e6g09h2d4 |
| bank_statement_100100_nov26.pdf | Cash - Operating bank statement | a3f8c21d94e7b065f3a1d29c4e87f0b2 |
| bank_statement_100200_nov26.pdf | Money Market bank statement | b4e9d32e05f8c176g4b2e30d5f98g1c3 |
| ar_aging_nov26.xlsx | AR sub-ledger aging | f8i3h76i49j2g510k8f6i74h9j32k5g7 |
| ap_aging_nov26.xlsx | AP sub-ledger aging | g9j4i87j50k3h621l9g7j85i0k43l6h8 |
| prepaid_schedule_nov26.xlsx | Prepaid amortization schedule | h0k5j98k61l4i732m0h8k96j1l54m7i9 |
| accrual_schedule_nov26.xlsx | Accrual schedule | e7h2g65h38i1f409j7e5h63g8i21j4f6 |
| ic_balance_report_nov26.xlsx | IC balance report (all three entities) | d6g1f54g27h0e398i6d4g52f7h10i3e5 |

---

*Close Orchestrator v0.1.0 · Period 2026-11 · Final attestation issued: 2026-12-05T17:00:00Z*  
*Sources: all specialist envelopes · all rec memos · config/close-calendar.yaml · config/entity-map.yaml · SKILL.md (finance-conventions)*
