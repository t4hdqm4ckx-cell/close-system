# November 2026 Month-End Close — BD2 Status Memo
**Entity:** Lumina Streaming USA, Inc. (LuminaUS) — Consolidated  
**Period:** Nov-26 (2026-11)  
**Business Day:** BD2 — December 2, 2026  
**Issued by:** Close Orchestrator v0.1.0  
**Issued at:** 2026-12-02T17:00:00Z  
**Distribution:** Controller · Assistant Controller · AP Manager · Consolidations Lead · Accruals Team · FP&A Manager · CFO

---

## Status summary

| Task | Owner | Target | Status |
|---|---|---|---|
| Bank reconciliation (100100, 100200) | AP Manager | BD2 noon | ✅ Complete — 11:30 PT |
| Intercompany matching (130100/130200) | Consolidations Lead | BD2 noon | ✅ Complete — 14:05 PT |
| Accrual review (210100–210400) | Accruals Team | BD2 15:00 | ✅ Complete — 15:40 PT |
| AR/AP tie-out (110100/110200/200100/200200) | Assistant Controller | BD2 15:00 | ✅ Complete — 16:15 PT |

**BD2 gate: PASSED.** All four reconciliations complete. No unresolved high-severity exceptions. Controller BD3 gate confirmation received at 16:45 PT.

---

## Reconciliation results summary

| Rec | GL balance | Support balance | Difference | Exceptions | Proposed JEs |
|---|---|---|---|---|---|
| Bank rec (100100/100200) | $160,728,200 | $160,728,200 | $0 | 1 low | 2 high-confidence |
| IC matching (130100/130200) | $24,350,000 | $24,350,000 | $0 | 1 medium (resolved) | 1 high-confidence |
| Accrual review (210100–210400) | $38,420,000 | $38,420,000 | $0 | 1 medium (approved) | 1 high-confidence |
| AR/AP tie-out | $187,640,000 | $187,640,000 | $0 | 1 low | 0 |

All accounts reconcile to zero difference.

---

## Exceptions routed

| Exception | Severity | Routed to | Resolution | Status |
|---|---|---|---|---|
| Outstanding check #14872 ($18,400, 47 days) | Low | AP Manager | Monitor; void at 60 days if not cleared | ✅ Noted |
| IC US/EMEA FX translation diff ($127,200) | Medium | Consolidations Lead | LuminaEMEA FX adj JE posted | ✅ Resolved |
| Stale accrual 210400 ($340,000, 91 days) | Medium | Accruals Team | Reversal JE approved | ✅ Resolved |
| AR 90+ day bucket at 3.8% | Low | Assistant Controller | Below threshold; monitor | ✅ Noted |

No high-severity exceptions. BD3 gate is clear.

---

## Proposed JEs queued for Controller review (BD4)

| JE ref | Description | Amount | Confidence |
|---|---|---|---|
| JE-PROP-001 | Bank service charge (debit 600700 / credit 100100) | $1,800 | High |
| JE-PROP-002 | MM interest income (debit 100200 / credit 700100) | $8,200 | High |
| JE-PROP-003 | IC FX adj — LuminaEMEA (debit 700300 / credit 230100) | $127,200 | High |
| JE-PROP-004 | Reverse stale accrual (debit 210400 / credit 600100) | $340,000 | High |

All four are high-confidence. Controller review and posting approval targeted BD4 17:00.

---

## BD3 actions — opening December 3, 08:00 PT

**Reconciliation Agent (amortization):**
- Prepaid amortization: accounts 120100, 120200, 120300 — target BD3 noon
- Content amortization: account 140100 vs. 500100 — target BD3 noon

**JE Reviewer (concurrent):**
- Full November JE log review — target BD3 15:00
- Reminder: JE-2026-11-0042 is a known seeded finding (round number, Saturday post, no support doc); Assistant Controller pre-briefed.

---

*Close Orchestrator v0.1.0 · Period 2026-11 · Run timestamp: 2026-12-02T17:00:00Z*  
*Sources: 02-reconciliations/ envelopes (all four) · config/close-calendar.yaml*
