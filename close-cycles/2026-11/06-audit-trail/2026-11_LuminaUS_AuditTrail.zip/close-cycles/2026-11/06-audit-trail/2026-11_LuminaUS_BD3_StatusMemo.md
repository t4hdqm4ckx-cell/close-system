# November 2026 Month-End Close — BD3 Status Memo
**Entity:** Lumina Streaming USA, Inc. (LuminaUS) — Consolidated  
**Period:** Nov-26 (2026-11)  
**Business Day:** BD3 — December 3, 2026  
**Issued by:** Close Orchestrator v0.1.0  
**Issued at:** 2026-12-03T16:30:00Z  
**Distribution:** Controller · Assistant Controller · AP Manager · Consolidations Lead · Accruals Team · FP&A Manager · CFO

---

## Status summary

| Task | Owner | Target | Status |
|---|---|---|---|
| Prepaid amortization (120100–120300) | Assistant Controller | BD3 noon | ✅ Complete — 11:20 PT |
| Content amortization (140100/500100) | Assistant Controller | BD3 noon | ✅ Complete — 11:45 PT |
| JE review pass 1 (full November log) | Assistant Controller | BD3 15:00 | ✅ Complete — 15:10 PT |

**BD3 gate: PASSED.** All three BD3 tasks complete. One high-severity JE exception (JE-2026-11-0042) was identified, documentation obtained, and exception cleared with Controller explicit acceptance at 15:10 PT. Controller BD4 gate confirmation received at 16:00 PT.

---

## BD3 results summary

### Prepaid amortization
- All three prepaid accounts (120100, 120200, 120300) tie to schedule. Zero exceptions.
- Three amortization JEs proposed (JE-PROP-005 through 007), all high-confidence.

### Content amortization
- Account 140100 (Capitalized Content - Net) ties to content amortization schedule.
- November content amortization: $4,200,000 (included in JE-PROP-005).
- No fully-amortized assets with residual balances.

### JE review
- 47 entries reviewed; 1 flagged.
- JE-2026-11-0042: $1.5M reclass, Saturday posting, no support doc — **HIGH severity**.
- Support document MKT-2026-11-042 obtained by Assistant Controller at 14:22 PT.
- Controller reviewed and cleared at 15:10 PT. Exception resolved.

---

## High-severity exception — RESOLVED

| Field | Detail |
|---|---|
| JE ref | JE-2026-11-0042 |
| Issue | Round-number $1.5M reclass, Saturday post, missing support |
| Resolution | MKT-2026-11-042 obtained and accepted by Controller |
| Cleared by | Controller — 2026-12-03T23:10:00Z |
| TB lock status | ✅ Cleared |

---

## Full JE queue for Controller review (BD4)

The following proposed JEs from BD2–BD3 recs are queued for Controller posting approval at BD4:

| JE ref | Description | Debit | Credit | Amount | Confidence |
|---|---|---|---|---|---|
| JE-PROP-001 | Bank service charge | 600700 | 100100 | $1,800 | High |
| JE-PROP-002 | MM interest income | 100200 | 700100 | $8,200 | High |
| JE-PROP-003 | IC FX adj (LuminaEMEA) | 700300 | 230100 | $127,200 | High |
| JE-PROP-004 | Reverse stale accrual | 210400 | 600100 | $340,000 | High |
| JE-PROP-005 | Content amortization | 500100 | 120100 | $4,200,000 | High |
| JE-PROP-006 | Software amortization | 600600 | 120200 | $380,000 | High |
| JE-PROP-007 | Insurance amortization | 600700 | 120300 | $95,000 | High |

Total proposed JEs: 7. Total dollar amount: $5,152,200. All high-confidence.

---

## BD4 actions — opening December 4, 08:00 PT

**Flux & Variance Agent:**
- P&L flux analysis (all income statement accounts, MoM + BvA) — target BD4 noon
- BS flux review — target BD4 noon
- Expected findings: Marketing - Performance ~$3.0M BvA unfavorable (note: $340K partially offset by JE-PROP-004 stale accrual reversal); Streaming Delivery/CDN ~$0.8M unfavorable; Advertising Revenue - APAC ~$0.7M unfavorable

**Controller:**
- TB review — target BD4 15:00
- Adjusting entries (JE-PROP-001 through 007) posting approval — target BD4 17:00

---

*Close Orchestrator v0.1.0 · Period 2026-11 · Run timestamp: 2026-12-03T16:30:00Z*  
*Sources: 02-reconciliations/ envelopes (prepaid) · 03-journal-entries/envelope.json · config/close-calendar.yaml*
