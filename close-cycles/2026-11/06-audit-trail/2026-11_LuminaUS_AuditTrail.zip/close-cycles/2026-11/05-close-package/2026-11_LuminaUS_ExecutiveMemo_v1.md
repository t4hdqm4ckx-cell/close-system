# November 2026 Close — Executive Memo
**Entity:** Lumina Streaming USA, Inc. — Consolidated  
**Period:** Nov-26 (2026-11)  
**Prepared by:** Close Reporting Agent v0.1.0  
**Reviewed by:** CFO  
**Status:** ✅ Approved — December 5, 2026, 15:00 PT

---

## 1. Period summary

November 2026 consolidated revenue was **$152.4M**, approximately $1.4M below budget (-0.9%) and $2.1M above October actuals (+1.4%). Gross margin came in at **54.8%**, roughly 120 basis points below plan, primarily due to higher CDN costs from elevated streaming volume. Operating income was **$18.2M**, $2.4M unfavorable to budget (-11.7%), with the bulk of the miss attributable to an accelerated Q4 marketing campaign. Total cash at November 30 was **$160.7M**, an increase of $3.2M from October.

---

## 2. Key variances

- **Marketing - Performance** ($2.66M unfavorable, -17.7% vs. budget): Q4 subscriber acquisition campaign launched two weeks early in response to a competitor event. Spend pulled forward from December; December budget has been reduced by $2.66M. Full-year marketing remains on plan.
- **Streaming Delivery / CDN** ($0.80M unfavorable, -9.9% vs. budget): Volume-driven overage from a 12% increase in peak streaming hours following two new original content releases in November. Unit rates held flat to contract.
- **Advertising Revenue — APAC** ($0.70M unfavorable, -3.8% vs. budget): Programmatic platform migration in APAC reduced fill rates for most of November. Migration completed November 28; December rates expected to normalize to approximately 82% sell-through.
- **Subscription Revenue** (+$0.60M favorable, +0.5% vs. budget): Stronger net subscriber additions in US and EMEA offset a modest APAC shortfall. Q4 subscriber growth is tracking above plan.

---

## 3. Close exceptions — resolved

The November close produced one high-severity JE exception and two medium-severity reconciliation findings. All were resolved within the close calendar:

- **JE-2026-11-0042** (High — weekend posting, missing support): $1.5M Q4 campaign reclassification posted Saturday November 29 without documentation. Campaign reclass memo MKT-2026-11-042 obtained BD3; Controller accepted at BD3 15:10 PT. Resolved — no impact on TB.
- **Stale accrual 210400** (Medium): $340K agency retainer accrual from August, contract terminated in September. Reversed via JE-PROP-004 ($340K credit to Marketing - Performance). Resolved — partially offsets marketing BvA variance.
- **IC US/EMEA FX translation** (Medium): $127,200 translation difference on EMEA shared services invoice. LuminaEMEA posted FX adjustment to account 700300 on BD2. Resolved — IC pairs mirror.

No exceptions carry into December. The November close is clean.

---

## 4. Cash and liquidity

| | November 30 | October 31 | Change |
|---|---|---|---|
| Cash - Operating (100100) | $142,508,200 | $139,420,000 | +$3,088,200 |
| Cash - Money Market (100200) | $18,218,200 | $18,010,000 | +$208,200 |
| **Total cash** | **$160,726,400** | **$157,430,000** | **+$3,296,400** |

Cash increase of $3.3M reflects strong subscription collections partially offset by Q4 marketing disbursements. Monthly burn rate (operating expenses excluding non-cash items) was approximately $42M. Liquidity position is healthy; no covenant concerns.

---

## 5. Open items

None. The November 2026 close is complete and clean.

---

## 6. Sign-off

| Role | Name | Date |
|---|---|---|
| CFO | — | December 5, 2026 |
| Controller | — | December 5, 2026 |
| FP&A Manager | — | December 4, 2026 |

---

*Close Reporting Agent v0.1.0 · Period 2026-11 · Sources: all specialist envelopes · TrialBalance (lumina_close_dataset.xlsx) · Run: 2026-12-05T10:30:00Z*
