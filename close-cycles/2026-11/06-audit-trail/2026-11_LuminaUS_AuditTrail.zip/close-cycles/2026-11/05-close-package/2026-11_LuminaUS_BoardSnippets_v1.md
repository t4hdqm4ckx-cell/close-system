# Board Snippets — November 2026
**Entity:** Lumina Streaming USA, Inc. — Consolidated  
**Period:** Nov-26 (2026-11)  
**Prepared by:** Close Reporting Agent v0.1.0 · CFO-approved: December 5, 2026

---

## Slide 1 — Income Statement Summary

| | Nov-26 Actual | Nov-26 Budget | Variance | Oct-26 Actual |
|---|---|---|---|---|
| **Revenue** | **$152.4M** | **$153.8M** | **($1.4M) -0.9%** | **$150.3M** |
| Subscription | $128.6M | $128.0M | +$0.6M ✅ | $127.4M |
| Advertising | $18.1M | $18.8M | ($0.7M) ⚠️ | $18.5M |
| Other | $5.7M | $5.6M | +$0.1M ✅ | $4.4M |
| **Gross Profit** | **$83.5M** | **$85.8M** | **($2.3M)** | **$82.1M** |
| Gross Margin | 54.8% | 55.8% | (100bps) | 54.6% |
| **Operating Income** | **$18.2M** | **$20.6M** | **($2.4M) -11.7%** | **$19.8M** |
| Operating Margin | 11.9% | 13.4% | (150bps) | 13.2% |
| **Net Income (est.)** | **$12.6M** | **$14.4M** | **($1.8M)** | **$13.8M** |

**Key message:** Revenue near budget; operating income miss driven by deliberate Q4 marketing pull-forward. No structural concerns.

---

## Slide 2 — Cash Bridge (October to November)

```
$157.4M  Opening cash (October 31)
+ $9.8M  Operating collections
- $4.8M  Marketing spend (includes Q4 pull-forward)
- $1.2M  Content license payments
- $3.7M  Payroll & benefits
- $0.9M  CDN / infrastructure
+ $0.2M  Interest income
+ $0.5M  Other net
─────────────────────────────────────
$160.7M  Closing cash (November 30)
```

**+$3.3M MoM increase.** Strong cash generation despite elevated marketing spend. No liquidity concerns.

---

## Slide 3 — Key Variance Explanations

### Marketing - Performance: ($2.66M) unfavorable — *EXPECTED*
> Q4 subscriber acquisition campaign accelerated by approximately two weeks in response to a competitor campaign launch. Spend pulled forward from December; December budget reduced by $2.66M. Full-year marketing on plan. Campaign brief on file (MKT-2026-11-042).

### CDN / Streaming Delivery: ($0.80M) unfavorable — *VOLUME DRIVEN*
> November streaming hours were 12% above forecast, driven by two new original content releases on November 7 and 21. CDN unit rates held to contract. Engineering reviewing Q1 renegotiation opportunity. No action required.

### Advertising Revenue — APAC: ($0.70M) unfavorable — *RESOLVED*
> Programmatic platform migration in APAC reduced automated fill rates to 74% (vs. 85% budget) for most of November. Migration completed November 28. December fill rates expected to normalize to ~82%. No structural ad market issue.

---

## Slide 4 — Subscriber KPIs

| Metric | Nov-26 | Budget | vs. Budget | Oct-26 | MoM |
|---|---|---|---|---|---|
| Total Subscribers | 48.2M | 47.8M | +400K ✅ | 47.6M | +600K |
| Churn Rate | 1.8% | 2.0% | (20bps) ✅ | 1.9% | (10bps) |
| Monthly ARPU | $2.67 | $2.68 | ($0.01) | $2.68 | ($0.01) |

**Subscriber growth ahead of budget.** Churn improving. ARPU stable. Q4 tracking above full-year plan.

---

## Slide 5 — Close Exceptions Summary

| Exception | Severity | Outcome |
|---|---|---|
| JE-2026-11-0042: Saturday posting, round number, no support doc | High | Resolved — documentation obtained BD3, Controller accepted |
| IC US/EMEA FX translation diff ($127K) | Medium | Resolved — LuminaEMEA adjustment posted BD2 |
| Stale marketing accrual ($340K, 91 days) | Medium | Resolved — reversed via JE; partially offsets marketing variance |
| AR 90+ day bucket at 3.8% | Low | Noted — below 5% threshold; monitor December |

**No open exceptions.** Close is clean. TB locked December 5, 2026.

---

*Close Reporting Agent v0.1.0 · Period 2026-11 · CFO-approved: 2026-12-05 · Run: 2026-12-05T10:30:00Z*
