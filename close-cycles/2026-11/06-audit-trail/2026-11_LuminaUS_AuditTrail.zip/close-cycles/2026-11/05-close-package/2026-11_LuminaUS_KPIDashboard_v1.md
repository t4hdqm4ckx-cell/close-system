# KPI Dashboard — November 2026
**Entity:** Lumina Streaming USA, Inc. — Consolidated  
**Period:** Nov-26 (2026-11)  
**Prepared by:** Close Reporting Agent v0.1.0 · Approved: CFO — December 5, 2026

---

## Financial KPIs

| Metric | Nov-26 Actual | Nov-26 Budget | Variance | Oct-26 Actual | MoM Change | YTD Actual | YTD Budget | YTD Variance |
|---|---|---|---|---|---|---|---|---|
| Total Revenue | $152.4M | $153.8M | ($1.4M) -0.9% | $150.3M | +$2.1M +1.4% | $1,674.4M | $1,687.5M | ($13.1M) -0.8% |
| Subscription Revenue | $128.6M | $128.0M | +$0.6M +0.5% | $127.4M | +$1.2M +0.9% | $1,413.2M | $1,407.8M | +$5.4M +0.4% |
| Advertising Revenue | $18.1M | $18.8M | ($0.7M) -3.8% | $18.5M | ($0.4M) -2.2% | $203.4M | $219.6M | ($16.2M) -7.4% |
| Other Revenue | $5.7M | $5.6M | +$0.1M +1.8% | $4.4M | +$1.3M +29.5% | $57.8M | $60.1M | ($2.3M) -3.8% |
| Gross Profit | $83.5M | $85.8M | ($2.3M) -2.7% | $82.1M | +$1.4M +1.7% | $920.1M | $940.5M | ($20.4M) -2.2% |
| Gross Margin % | 54.8% | 55.8% | (100bps) | 54.6% | +20bps | 54.9% | 55.7% | (80bps) |
| Operating Income | $18.2M | $20.6M | ($2.4M) -11.7% | $19.8M | ($1.6M) -8.1% | $218.2M | $234.8M | ($16.6M) -7.1% |
| Operating Margin % | 11.9% | 13.4% | (150bps) | 13.2% | (130bps) | 13.0% | 13.9% | (90bps) |
| Net Income (est.) | $12.6M | $14.4M | ($1.8M) -12.5% | $13.8M | ($1.2M) -8.7% | $151.4M | $163.5M | ($12.1M) -7.4% |

---

## Balance sheet KPIs

| Metric | Nov-26 | Oct-26 | Change |
|---|---|---|---|
| Total Cash | $160.7M | $157.4M | +$3.3M |
| Total AR | $93.2M | $89.6M | +$3.6M |
| AR 90+ day % | 3.8% | 3.2% | +60bps |
| Total AP | $94.4M | $91.2M | +$3.2M |
| Prepaid Assets | $22.2M | $26.8M | ($4.6M) |
| IC Receivables | $24.4M | $24.1M | +$0.3M |
| Accrued Liabilities | $38.1M | $39.4M | ($1.3M) |

---

## Operating KPIs (streaming)

| Metric | Nov-26 | Oct-26 | MoM | Budget | vs. Budget |
|---|---|---|---|---|---|
| Total Subscribers (est.) | 48.2M | 47.6M | +600K +1.3% | 47.8M | +400K favorable |
| Monthly ARPU (Subscription) | $2.67 | $2.68 | ($0.01) | $2.68 | ($0.01) |
| Churn Rate (est.) | 1.8% | 1.9% | (10bps) | 2.0% | (20bps) favorable |
| Streaming Hours (peak, indexed) | 112 | 100 | +12% | 100 | +12% (CDN impact) |
| APAC Ad Sell-Through | 74% | 82% | (8pts) | 85% | (11pts) |

---

## Cash bridge — October to November

| Item | Amount |
|---|---|
| October ending cash | $157,430,000 |
| Operating collections (net) | +$9,840,000 |
| Marketing disbursements | ($4,820,000) |
| Content license payments | ($1,200,000) |
| Payroll and benefits | ($3,730,000) |
| CDN / infrastructure | ($890,000) |
| Interest income received | +$208,200 |
| Other net | +$488,200 |
| **November ending cash** | **$160,726,400** |

---

*Close Reporting Agent v0.1.0 · Period 2026-11 · Run: 2026-12-05T10:30:00Z*
