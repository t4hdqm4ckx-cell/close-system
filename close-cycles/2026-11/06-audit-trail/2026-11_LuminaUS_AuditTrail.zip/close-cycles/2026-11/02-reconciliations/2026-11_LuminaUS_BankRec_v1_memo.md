# Bank Reconciliation — Memo
**Entity:** LuminaUS  
**Period:** Nov-26 (2026-11)  
**Accounts:** 100100 Cash - Operating · 100200 Cash - Money Market  
**Preparer:** Reconciliation Agent v0.1.0  
**Reviewer:** AP Manager  
**Status:** ✅ Reconciled — approved BD2 11:30 PT

---

## 1. Executive summary

Both cash accounts reconcile to bank statement as of November 30, 2026. Net difference after reconciling items: $0. Two book-side adjusting entries are proposed (bank service charge and money market interest). One low-severity outstanding check noted; below the 60-day threshold, no current-period action required.

---

## 2. Reconciliation — 100100 Cash - Operating

| | Amount (USD) |
|---|---|
| Bank statement balance — November 30, 2026 | $142,528,400 |
| Less: outstanding checks | ($18,400) |
| Less: bank service charge not yet in GL | ($1,800) |
| **Adjusted bank balance** | **$142,508,200** |
| | |
| GL balance per trial balance | $142,510,000 |
| Less: bank service charge (proposed JE) | ($1,800) |
| **Adjusted book balance** | **$142,508,200** |
| | |
| **Difference** | **$0** |

## 3. Reconciliation — 100200 Cash - Money Market

| | Amount (USD) |
|---|---|
| Bank statement balance — November 30, 2026 | $18,218,200 |
| **Adjusted bank balance** | **$18,218,200** |
| | |
| GL balance per trial balance | $18,210,000 |
| Plus: interest income not yet in GL (proposed JE) | $8,200 |
| **Adjusted book balance** | **$18,218,200** |
| | |
| **Difference** | **$0** |

---

## 4. Exceptions

### LOW — Outstanding check #14872
- **Payee:** Broadridge Systems  
- **Amount:** $18,400  
- **Age:** 47 days  
- **Status:** Below 60-day void threshold. No action this period.  
- **Next review:** BD2, December cycle. Void and re-issue if still outstanding.

---

## 5. Proposed adjusting journal entries

### JE-PROP-001 — Bank service charge
| Field | Value |
|---|---|
| Description | Record November bank service charge |
| Debit | 600700 Professional Fees — $1,800 |
| Credit | 100100 Cash - Operating — $1,800 |
| Period | 2026-11 |
| Support | BANK-2026-11-001, row 47 |
| Confidence | High |

### JE-PROP-002 — Money market interest income
| Field | Value |
|---|---|
| Description | Record November money market interest income |
| Debit | 100200 Cash - Money Market — $8,200 |
| Credit | 700100 Interest Income — $8,200 |
| Period | 2026-11 |
| Support | BANK-2026-11-002, row 12 |
| Confidence | High |

---

## 6. Reviewer sign-off

**AP Manager — approved 2026-12-02T11:30:00Z**  
Both proposed JEs forwarded to Controller for posting approval on BD4.

---

*Reconciliation Agent v0.1.0 · Sources: bank_statement_100100_nov26.pdf · bank_statement_100200_nov26.pdf · TrialBalance (lumina_close_dataset.xlsx) · Run: 2026-12-02T10:14:00Z*
