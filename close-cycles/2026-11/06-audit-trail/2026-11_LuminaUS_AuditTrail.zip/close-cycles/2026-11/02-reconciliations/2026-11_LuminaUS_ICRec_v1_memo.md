# Intercompany Reconciliation — Memo
**Entity:** LuminaUS (consolidated view — all three IC pairs)  
**Period:** Nov-26 (2026-11)  
**Accounts in scope:**
- LuminaUS 130100 (IC Receivable - EMEA) ↔ LuminaEMEA 230100 (IC Payable - LuminaUS)
- LuminaUS 130200 (IC Receivable - APAC) ↔ LuminaAPAC 230200 (IC Payable - LuminaUS)
- LuminaEMEA 130100 (IC Receivable - APAC) ↔ LuminaAPAC 230100 (IC Payable - EMEA)

**Preparer:** Reconciliation Agent v0.1.0  
**Reviewer:** Consolidations Lead  
**Status:** ✅ Reconciled — approved BD2 14:05 PT (post FX adjustment confirmation)

---

## 1. Executive summary

All three intercompany pairs reconcile after a single FX translation adjustment on the LuminaUS/EMEA pair. The difference ($127,200) is a pure translation item arising from rate movement between invoice date and month-end. LuminaEMEA has confirmed the FX adjustment JE will be posted by BD3 09:00. The LuminaUS/APAC and EMEA/APAC pairs reconcile without exception.

---

## 2. IC matrix — USD balances as of November 30, 2026

| Pair | Receivable entity | Receivable (USD) | Payable entity | Payable (USD) | Difference | Status |
|---|---|---|---|---|---|---|
| US ↔ EMEA | LuminaUS 130100 | $14,750,000 | LuminaEMEA 230100 | $14,622,800 | $127,200 | ⚠️ FX adj. pending |
| US ↔ APAC | LuminaUS 130200 | $9,600,000 | LuminaAPAC 230200 | $9,600,000 | $0 | ✅ |
| EMEA ↔ APAC | LuminaEMEA 130100 | $4,820,000 | LuminaAPAC 230100 | $4,820,000 | $0 | ✅ |

FX rates applied (period-end spot):
- EUR/USD: 1.0834 (November 30, 2026 — source: FX-2026-11-003)
- SGD/USD: 0.7521 (November 30, 2026 — source: FX-2026-11-003)

---

## 3. Exceptions

### MEDIUM — US/EMEA FX translation difference — $127,200

- **Root cause:** Shared service invoice dated November 28 recorded in EUR by LuminaEMEA. The intra-period rate movement between November 28 (1.0748) and November 30 month-end rate (1.0834) produces a $127,200 USD translation difference.
- **Classification:** Pure translation — not a disputed amount, not a timing difference. Both entities recorded the same underlying transaction.
- **Resolution:** LuminaEMEA to post FX gain/loss JE (debit 700300, credit 230100 — $127,200) in the November period.
- **Confirmed:** Consolidations Lead confirmed adjustment posted at 2026-12-02T13:50:00Z. Post-adjustment balance: $14,750,000 on both sides.

---

## 4. Proposed adjusting journal entry

### JE-PROP-003 — LuminaEMEA FX translation adjustment
| Field | Value |
|---|---|
| Entity | LuminaEMEA |
| Description | FX translation adjustment on IC payable to LuminaUS — November shared services invoice |
| Debit | 700300 FX Gain/Loss — $127,200 |
| Credit | 230100 IC Payable - LuminaUS — $127,200 |
| Period | 2026-11 |
| Support | FX-2026-11-003; IC balance report row 14 |
| Confidence | High |
| Status | ✅ Confirmed posted by LuminaEMEA — 2026-12-02T13:50:00Z |

---

## 5. Reviewer sign-off

**Consolidations Lead — approved 2026-12-02T14:05:00Z**  
FX adjustment confirmed posted. All IC pairs reconciled. No outstanding items.

---

*Reconciliation Agent v0.1.0 · Sources: ic_balance_report_nov26.xlsx · TrialBalance (lumina_close_dataset.xlsx) · Run: 2026-12-02T10:52:00Z*
