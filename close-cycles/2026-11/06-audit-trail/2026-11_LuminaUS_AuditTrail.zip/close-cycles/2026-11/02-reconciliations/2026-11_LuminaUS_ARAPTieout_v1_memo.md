# AR / AP Sub-Ledger Tie-Out — Memo
**Entity:** LuminaUS  
**Period:** Nov-26 (2026-11)  
**Accounts:** 110100 AR - Subscriptions · 110200 AR - Advertising · 200100 AP - Trade · 200200 AP - Content Vendors  
**Preparer:** Reconciliation Agent v0.1.0  
**Reviewer:** Assistant Controller  
**Status:** ✅ Reconciled — approved BD2 16:15 PT

---

## 1. Executive summary

All four AR and AP accounts tie to sub-ledger aging as of November 30, 2026. Net difference: $0. One low-severity observation: the 90+ day AR bucket is at 3.8% of total AR, below the 5% flag threshold. No negative AR balances. No AP disputes or payments overdue beyond standard terms in material amounts. No adjusting entries proposed.

---

## 2. AR tie-out

| Account | Account name | GL balance | Sub-ledger total | Difference | Status |
|---|---|---|---|---|---|
| 110100 | AR - Subscriptions | $74,800,000 | $74,800,000 | $0 | ✅ |
| 110200 | AR - Advertising | $18,400,000 | $18,400,000 | $0 | ✅ |
| **AR Total** | | **$93,200,000** | **$93,200,000** | **$0** | ✅ |

### AR aging — 110100 Subscriptions

| Bucket | Balance | % of total |
|---|---|---|
| Current (0–30 days) | $58,620,000 | 78.4% |
| 31–60 days | $10,240,000 | 13.7% |
| 61–90 days | $3,100,000 | 4.1% |
| 90+ days | $2,840,000 | 3.8% |
| **Total** | **$74,800,000** | **100%** |

90+ day balance of $2,840,000 (3.8%) is below the 5% flag threshold. Composed of 14 enterprise accounts on extended terms. No credit risk flags identified.

### AR aging — 110200 Advertising

| Bucket | Balance | % of total |
|---|---|---|
| Current (0–30 days) | $15,800,000 | 85.9% |
| 31–60 days | $2,600,000 | 14.1% |
| 61–90 days | $0 | 0% |
| 90+ days | $0 | 0% |
| **Total** | **$18,400,000** | **100%** |

Clean aging profile. No exceptions.

---

## 3. AP tie-out

| Account | Account name | GL balance | Sub-ledger total | Difference | Status |
|---|---|---|---|---|---|
| 200100 | AP - Trade | $52,840,000 | $52,840,000 | $0 | ✅ |
| 200200 | AP - Content Vendors | $41,600,000 | $41,600,000 | $0 | ✅ |
| **AP Total** | | **$94,440,000** | **$94,440,000** | **$0** | ✅ |

No AP items outstanding beyond net-30 terms in excess of $250K. Standard vendor payment cycle operating normally.

---

## 4. Exceptions

### LOW — AR 90+ day bucket at 3.8%

- **Amount:** $2,840,000  
- **Threshold:** 5% of total AR ($74,800,000 = $3,740,000)  
- **Status:** Below threshold. 14 enterprise accounts on extended terms (net-60 plus 30-day grace period per contract). No dispute flags.  
- **Action:** None required. Monitor next cycle.

---

## 5. Reviewer sign-off

**Assistant Controller — approved 2026-12-02T16:15:00Z**  
All accounts tie. No adjusting entries required from this rec.

---

*Reconciliation Agent v0.1.0 · Sources: ar_aging_nov26.xlsx · ap_aging_nov26.xlsx · TrialBalance (lumina_close_dataset.xlsx) · Run: 2026-12-02T14:48:00Z*
