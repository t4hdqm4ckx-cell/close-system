# Accrual Review — Memo
**Entity:** LuminaUS  
**Period:** Nov-26 (2026-11)  
**Accounts:** 210100 Accrued Bonus · 210200 Accrued Vacation · 210300 Accrued Content Costs · 210400 Accrued Marketing  
**Preparer:** Reconciliation Agent v0.1.0  
**Reviewer:** Accruals Team  
**Status:** ✅ Reconciled — approved BD2 15:40 PT (stale accrual reversal approved)

---

## 1. Executive summary

Accrual schedule ties to GL balance of $38,420,000 across all four accrued liability accounts. One medium-severity finding: a stale $340,000 marketing accrual (91 days, terminated agency contract) was identified and approved for reversal. Post-reversal, all accruals are current and supported. No high-severity exceptions.

---

## 2. Accrual schedule tie-out

| Account | Account name | GL balance | Schedule balance | Difference | Status |
|---|---|---|---|---|---|
| 210100 | Accrued Bonus | $18,750,000 | $18,750,000 | $0 | ✅ |
| 210200 | Accrued Vacation | $4,830,000 | $4,830,000 | $0 | ✅ |
| 210300 | Accrued Content Costs | $14,500,000 | $14,500,000 | $0 | ✅ |
| 210400 | Accrued Marketing | $340,000 | $340,000 | $0 | ✅ |
| **Total** | | **$38,420,000** | **$38,420,000** | **$0** | ✅ |

*Note: 210400 balance reflects the stale item to be reversed; post-reversal balance will be $0.*

---

## 3. Accrual aging analysis

| Account | Accruals >30 days | Accruals >60 days | Accruals >90 days | Notes |
|---|---|---|---|---|
| 210100 | $0 | $0 | $0 | Annual bonus — current period accrual, appropriate |
| 210200 | $0 | $0 | $0 | Vacation — rolling balance, current |
| 210300 | $0 | $0 | $0 | Content costs — all current period |
| 210400 | $340,000 | $340,000 | $340,000 | ⚠️ Stale — see exception below |

---

## 4. Exception

### MEDIUM — Stale accrual in 210400 (Accrued Marketing) — $340,000

- **Accrual date:** August 31, 2026 (age: 91 days)
- **Original purpose:** Q3 agency retainer — third-party creative agency
- **Status:** Contract terminated September 2026. No invoice received. Reversal was not posted in September or October.
- **Materiality:** $340,000 — below auto-investigate threshold ($250K note: amount exceeds $250K; elevated to auto-investigate). Reviewed in full.
- **Disposition:** Accruals Team confirmed contract termination and absence of any outstanding invoice obligation. Reversal approved.
- **Resolution:** JE-PROP-004 approved by Accruals Team at 2026-12-02T15:40:00Z.

---

## 5. Proposed adjusting journal entry

### JE-PROP-004 — Reverse stale marketing accrual
| Field | Value |
|---|---|
| Description | Reverse stale Q3 agency retainer accrual — contract terminated September 2026 |
| Debit | 210400 Accrued Marketing — $340,000 |
| Credit | 600100 Marketing - Performance — $340,000 |
| Period | 2026-11 |
| Support | AMORT-2026-08-004; Accrual schedule row 22 |
| Confidence | High |
| Impact | Reduces Marketing - Performance expense by $340,000 — partially offsets BvA unfavorable variance; Flux Agent notified |

---

## 6. Reviewer sign-off

**Accruals Team — approved 2026-12-02T15:40:00Z**  
Stale accrual confirmed for reversal. JE-PROP-004 forwarded to Controller for posting approval BD4.

---

*Reconciliation Agent v0.1.0 · Sources: accrual_schedule_nov26.xlsx · TrialBalance (lumina_close_dataset.xlsx) · Run: 2026-12-02T13:22:00Z*
